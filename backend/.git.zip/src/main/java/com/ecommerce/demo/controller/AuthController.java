package com.ecommerce.demo.controller;

import com.ecommerce.demo.dto.AuthRequest;
import com.ecommerce.demo.dto.AuthResponse;
import com.ecommerce.demo.dto.RegisterRequest;
import com.ecommerce.demo.model.Customer;
import com.ecommerce.demo.model.User;
import com.ecommerce.demo.repository.CustomerRepository;
import com.ecommerce.demo.repository.UserRepository;
import com.ecommerce.demo.security.JwtUtils;
import com.ecommerce.demo.service.CustomerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final CustomerRepository customerRepository;
    private final CustomerService customerService;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;

    public AuthController(AuthenticationManager authenticationManager,
                          UserRepository userRepository,
                          CustomerRepository customerRepository,
                          CustomerService customerService,
                          PasswordEncoder passwordEncoder,
                          JwtUtils jwtUtils) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.customerRepository = customerRepository;
        this.customerService = customerService;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtils = jwtUtils;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Username is already taken!");
        }

        String assignedRole = (request.getRole() != null && !request.getRole().isBlank())
                ? request.getRole()
                : "ROLE_USER";

        String encodedPassword = passwordEncoder.encode(request.getPassword());

        User user = new User(
                request.getUsername(),
                encodedPassword,
                assignedRole
        );
        userRepository.save(user);

        Customer customer = new Customer();

        customer.setFirstName(request.getFirstName() != null ? request.getFirstName() : request.getUsername());
        customer.setLastName(request.getLastName() != null ? request.getLastName() : "");
        customer.setEmail(request.getEmail() != null ? request.getEmail() : request.getUsername());
        customer.setPhone(request.getPhone() != null ? request.getPhone() : "");
        customer.setPassword(encodedPassword);

        customerService.registerCustomer(customer);

        return ResponseEntity.ok("User and Customer registered successfully with role: " + assignedRole);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest request) {

        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        String token = jwtUtils.generateToken(request.getUsername());

        Customer customer = customerRepository.findByEmail(request.getUsername()).orElse(null);

        Long customerId = null;
        if (customer != null) {
            customerId = customer.getIdCustomer();
        } else {
            List<Customer> all = customerRepository.findAll();
            if (!all.isEmpty()) {
                customerId = all.get(0).getIdCustomer();
            }
        }

        return ResponseEntity.ok(new AuthResponse(token, customerId));
    }
}